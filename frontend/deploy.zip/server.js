const express = require('express');
const app = express();
app.use(express.json());
app.use(express.static('public'));

const FUNC_BASE = process.env.FUNCTION_APP_URL || 'https://cloud-compiler-func.azurewebsites.net/api';

app.post('/api/compile', async (req, res) => {
  const fetch = (await import('node-fetch')).default;
  const r = await fetch(FUNC_BASE + '/TriggerCompile', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(req.body)});
  res.json(await r.json());
});

app.post('/api/explain', async (req, res) => {
  const fetch = (await import('node-fetch')).default;
  const r = await fetch(FUNC_BASE + '/ExplainError', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(req.body)});
  res.json(await r.json());
});

app.get('/api/history', async (req, res) => {
  const fetch = (await import('node-fetch')).default;
  const r = await fetch(FUNC_BASE + '/GetHistory?userId=' + (req.query.userId || 'anonymous'));
  res.json(await r.json());
});

app.listen(process.env.PORT || 3000, () => console.log('Frontend running on port ' + (process.env.PORT || 3000)));
